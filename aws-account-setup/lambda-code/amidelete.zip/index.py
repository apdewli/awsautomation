import os
import boto3
import datetime
from dateutil import parser


# Optional environment variables:-
OWNER_ID = os.environ.get('OWNER_ID')
# If you do not provide account id in environment variables then lambda role must have permissions for sts
SOURCE_REGION = os.environ.get('SOURCE_REGION', os.environ['AWS_REGION'])
AMI_NAME_DELIMITER = os.environ.get('AMI_NAME_DELIMITER', '/')
# ----------------------------------

AMI_NAME_DELIMITER_OPTIONS = ['/', '.', '-']

if AMI_NAME_DELIMITER not in AMI_NAME_DELIMITER_OPTIONS:
    raise Exception(
        'Invalid AMI_NAME_DELIMITER please choose from: {}'.format(AMI_NAME_DELIMITER_OPTIONS)
    )

if not OWNER_ID:
    sts_client = boto3.client('sts')
    OWNER_ID = str(sts_client.get_caller_identity()['Account'])


ec2_client = boto3.client('ec2', region_name=SOURCE_REGION)


def lambda_handler(event, context):
    return handler(event, context)


def handler(event, context):
    print(OWNER_ID)
    print(SOURCE_REGION)
    response = ec2_client.describe_images(
        Owners=[
            str(OWNER_ID),
        ]
    )

    images_to_be_deleted_dict = {}
    now = datetime.datetime.now()

    if response.get('Images'):
        print(len(response['Images']), 'images found!')
        for image in response['Images']:
            dash_split_list = image['Name'].split(AMI_NAME_DELIMITER)
            if len(dash_split_list) > 2:
                if dash_split_list[-2] == 'Lambda':
                    RETENTION_DAYS = dash_split_list[-1][:-1]
                    expiration_date = now - datetime.timedelta(int(RETENTION_DAYS))
                    image_creation_date = parser.parse(image['CreationDate']).replace(tzinfo=None)
                    if image_creation_date < expiration_date:
                        print('Found image to be deleted with image_id:{0}'.format(image['ImageId']))
                        try:
                            ebs_list = images_to_be_deleted_dict[image['ImageId']]
                        except KeyError:
                            ebs_list = []
                            images_to_be_deleted_dict[image['ImageId']] = ebs_list
                        for mapping in image['BlockDeviceMappings']:
                            ebs_list.append(mapping['Ebs']['SnapshotId'])
                            print('Found snapshot to be deleted with snap_id:{0}'.format(
                                mapping['Ebs']['SnapshotId'])
                            )
    else:
        print('No images found!')

    for image_id, snapshot_id_list in images_to_be_deleted_dict.items():
        ec2_client.deregister_image(
            DryRun=False,
            ImageId=image_id
        )
        print('Deleted {0}'.format(image_id))
        for snapshot_id in snapshot_id_list:
            ec2_client.delete_snapshot(
                SnapshotId=snapshot_id
            )
            print('Deleted {0}'.format(snapshot_id))
    return 'Success'