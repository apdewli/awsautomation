import boto3
import os
import datetime
import re
from dateutil import parser

# Optional environment variables:-
OWNER_ID = os.environ.get('OWNER_ID')  # acount id
# If you do not provide account id in environment variables then lambda role must have permissions for sts
SOURCE_REGION = os.environ.get('SOURCE_REGION', os.environ['AWS_REGION'])
BACKUP_TAG_KEY = os.environ.get('BACKUP_TAG_KEY', 'Backup')
ENV_TAG_KEY = os.environ.get('ENV_TAG_KEY', 'environment')
MAIL_SENDER = os.environ.get('MAIL_SENDER')
RECIPIENT_LIST = os.environ.get('RECIPIENT_LIST')
AMI_NAME_DELIMITER = os.environ.get('AMI_NAME_DELIMITER', '/')

# ----------------------------------

AMI_NAME_DELIMITER_OPTIONS = ['/', '.', '-']

if AMI_NAME_DELIMITER not in AMI_NAME_DELIMITER_OPTIONS:
    raise Exception(
        'Invalid AMI_NAME_DELIMITER please choose from: {}'.format(AMI_NAME_DELIMITER_OPTIONS)
    )

if not OWNER_ID:
    sts_client = boto3.client('sts')
    OWNER_ID = str(sts_client.get_caller_identity()['Account'])

regex_frequency = r'^f=(?P<frequency_time_duration>[0-9]+)(?P<frequency_time_unit>[hd])$'
regex_retention = r'^r=(?P<retention_time_duration>[0-9]+)(?P<retention_time_unit>[d])$'

ec2_source_client = boto3.client('ec2', region_name=SOURCE_REGION)
mail_client = boto3.client('ses')


def init_variable():
    global ec2_instances
    global successfully_initiated_ami_list
    global failed_ami_list
    global errors_list

    ec2_instances = {}
    successfully_initiated_ami_list = []
    failed_ami_list = []
    errors_list = []


def lambda_handler(event, context):
    return handler(event, context)


def handler(event, context):
    init_variable()
    # Discover all running instances and find the ones with correct tags.
    now = datetime.datetime.now()
    data = ec2_source_client.describe_instances()
    reservations = data['Reservations']
    for reservation in reservations:
        for instance in reservation['Instances']:
            try:
                tags = instance['Tags']
            except KeyError:
                continue

            BACKUP_TAG_VALUE=''
            ENV_TAG_VALUE=''
            for tag in tags:
                if tag['Key'] == BACKUP_TAG_KEY:
                    BACKUP_TAG_VALUE = tag['Value']
                if tag['Key'] == ENV_TAG_KEY:
                    ENV_TAG_VALUE = tag['Value']

            value_dict = {}
            if BACKUP_TAG_VALUE and BACKUP_TAG_VALUE.lower() != 'no':
                print("processing for instance: {}".format(instance['InstanceId']))
                value_dict = {'tags': tags}
                try:
                    # get above str from lmabda config
                    config_list = os.environ.get('CONFIG_{}'.format(ENV_TAG_VALUE), '').split(':')  # r=1d, f=1d
                    frequency_str, retention_str = config_list
                    print(config_list)
                except Exception as e:
                    print(e)
                    print("make sure CONFIG_ is set properly in right order, eg: CONFIG_dev = f=1d:r=1d.")
                    error_str = 'Invalid backup env tag value:{tag_val} in {ins_id} or no config'.format(
                        tag_val=ENV_TAG_VALUE,
                        ins_id=instance['InstanceId']
                    )
                    errors_list.append(error_str)
                    print(error_str)
                    continue
                frequency = re.match(regex_frequency, frequency_str)
                if frequency is None:
                    error_str = 'Could not match frequency string:{freq_str} in {ins_id}'.format(
                        freq_str=frequency_str,
                        ins_id=instance['InstanceId']
                    )
                    errors_list.append(error_str)
                    print(error_str)
                    continue
                value_dict.update(frequency.groupdict())
                retention = re.match(regex_retention, retention_str)
                if retention is None:
                    error_str = 'Could not match retention string:{ret_str} in {ins_id}'.format(
                        ret_str=retention_str,
                        ins_id=instance['InstanceId']
                    )
                    errors_list.append(error_str)
                    print(error_str)
                    continue
                value_dict.update(retention.groupdict())
                print('Found instance {ins_id}'.format(ins_id=instance['InstanceId']))
                ec2_instances.update({instance['InstanceId']: value_dict})

    # Create image of discovered instances in the previous step, add a timestamp with image name
    # to keep subsequent names of image of same instance unique
    if ec2_instances:
        all_ami_dict = {}
        response = ec2_source_client.describe_images(
            Owners=[str(OWNER_ID), ]
        )
        if response.get('Images'):
            print(len(response['Images']), 'images found!')
            for image in response['Images']:
                dash_split_list = image['Name'].split(AMI_NAME_DELIMITER)
                if len(dash_split_list) > 2 and dash_split_list[-2] == 'Lambda':
                    image_name = '{limiter}'.format(limiter=AMI_NAME_DELIMITER).join(
                        dash_split_list[:-3]
                    )
                    image_creation_date = parser.parse(image['CreationDate']).replace(tzinfo=None)
                    try:
                        old_creation_date = all_ami_dict[image_name]
                    except KeyError:
                        all_ami_dict[image_name] = image_creation_date
                    else:
                        all_ami_dict[image_name] = max(old_creation_date, image_creation_date)

        for instance_id, data_dict in ec2_instances.items():
            ami_name_tag = None
            time_stamp = str(datetime.datetime.now()).replace('-', '_').replace(' ', '').replace(':', '_').replace('.',
                                                                                                                   '')
            for tag in data_dict['tags']:
                if tag['Key'] == 'Name':
                    ami_name_tag = tag['Value']
            if ami_name_tag is None:
                error_str = 'Instance {ins_id} missing "Name" tag.'.format(ins_id=instance_id)
                errors_list.append(error_str)
                print(error_str)
                continue
            ami_name = (
                    ami_name_tag + AMI_NAME_DELIMITER + time_stamp + AMI_NAME_DELIMITER +
                    'Lambda' + AMI_NAME_DELIMITER + data_dict['retention_time_duration'] +
                    data_dict['retention_time_unit']
            )
            try:
                last_run_datetime = all_ami_dict[ami_name_tag]
            except KeyError:
                create_image(ami_name, instance_id)
            else:
                if data_dict['frequency_time_unit'] == 'h':
                    time_delta_expected = datetime.timedelta(hours=int(data_dict['frequency_time_duration']))
                else:
                    time_delta_expected = datetime.timedelta(days=int(data_dict['frequency_time_duration']))
                time_delta_expected = time_delta_expected - datetime.timedelta(minutes=15)
                time_delta_actual = now - last_run_datetime
                if time_delta_actual >= time_delta_expected:
                    create_image(ami_name, instance_id)

    print('Errors:\n', errors_list)
    print('Failed:\n', failed_ami_list)
    print('Success:\n', successfully_initiated_ami_list)

    if (MAIL_SENDER and RECIPIENT_LIST and
            (errors_list or failed_ami_list or successfully_initiated_ami_list)
    ):
        email_content_text = 'Errors:\n'
        email_content_text += '\n'.join(errors_list)
        email_content_text += '\nFailed:\n'
        email_content_text += '\n'.join(failed_ami_list)
        email_content_text += '\nSuccessfully initiated:\n'
        email_content_text += '\n'.join(successfully_initiated_ami_list)
        recipient_list = RECIPIENT_LIST.split(',')
        return send_mail(MAIL_SENDER, recipient_list, email_content_text)
    return 'Check Logs'


def create_image(ami_name, instance_id):
    try:
        response = ec2_source_client.create_image(
            DryRun=False,
            Name=ami_name,
            InstanceId=instance_id,
            NoReboot=True,
        )

    except Exception as e:
        failed_ami_list.append(
            'Instance {ins_id} error: "{error}"'.format(
                ins_id=instance_id,
                error=str(e.__class__.__name__) + ': ' + str(e)
            )
        )
    else:
        success_str = (
                'Successfully Initiated Image Creation with id' +
                ': {img_id} and name: {img_name}'
        ).format(
            img_id=response['ImageId'], img_name=ami_name
        )
        successfully_initiated_ami_list.append(success_str)


def send_mail(sender, recipient_list, body_text):
    MAIL_SUBJECT = 'AMI Creation Logs for account: {acc_id}(Success:{success_count},Error:{error_count},Failed:{failed_count})'
    body = {
        'Text': {
            'Data': body_text,
            'Charset': 'utf-8'
        }
    }
    try:
        mail_client.send_email(
            Source=sender,
            Destination={
                'ToAddresses': recipient_list
            },
            Message={
                'Subject': {
                    'Data': MAIL_SUBJECT.format(
                        acc_id=OWNER_ID,
                        success_count=len(successfully_initiated_ami_list),
                        error_count=len(errors_list),
                        failed_count=len(failed_ami_list)
                    ),
                    'Charset': 'utf-8'
                },
                'Body': body
            }
        )
    except Exception as e:
        print('Mail Sending Error: ', str(e.__class__.__name__), str(e))